-- Scenes:
-- 0 <-> menu
-- 1 <-> how
-- 2 <-> game
local scene = 0
local active = 0
local scale = 10


local score = 0
local highScore = 0

local Point = class()
function Point:init(x, y)
	self.x = x
	self.y = y
end
function Point:draw(gc)
	gc:fillRect(self.x, self.y, scale, scale)
end

local dir = 0
local snake = {
	Point(0, 0)
}

local apple = Point(0, 0)

function on.resize()
	width = platform.window:width()
	height = platform.window:height()
end

function initGame()
	score = 0
	dir = 0
	snake = {
		Point(scale, math.floor(height / (scale * 2)) * scale)
	}
	apple = Point(math.floor(width / scale) * scale - 2 * scale, math.floor(height / (scale * 2)) * scale)
end

function RandomiseApplePosition()
	apple = Point(math.random(1, math.floor(width / scale) - 1) * scale, math.random(1, math.floor(height / scale) - 1) * scale)
	for i = 1, #snake do
		if snake[i].x == apple.x and snake[i].y == apple.y then
			RandomiseApplePosition()
		end
	end
end

function on.paint(gc)
	if scene == 0 then
		-- render
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Snake", width / 2 - gc:getStringWidth("Snake") / 2, 14, "top")
		gc:setFont("sansserif", "r", 9)
		gc:drawString("Developed by Matthew James", width / 2 - gc:getStringWidth("Developed by Matthew James") / 2, 56, "top")
		gc:setFont("sansserif", "r", 14)
		if active == 0 then
			gc:drawString("> Play <", width / 2 - gc:getStringWidth("> Play <") / 2, 100)
		else
			gc:drawString("Play", width / 2 - gc:getStringWidth("Play") / 2, 100)
		end
		if active == 1 then
			gc:drawString("> How <", width / 2 - gc:getStringWidth("> How <") / 2, 130)
		else
			gc:drawString("How", width / 2 - gc:getStringWidth("How") / 2, 130)
		end
	elseif scene == 1 then
		-- render
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Snake", width / 2 - gc:getStringWidth("Snake") / 2, 14, "top")
		gc:setFont("sansserif", "r", 14)
		gc:drawString("Using the arrow keys on your", 18, 50, "top")
		gc:drawString("calculator,   navigate  to   the", 18, 70, "top")
		gc:drawString("apple  in  order  to  grow your", 18, 90, "top")
		gc:drawString("snake.  Avoid  your  tail   and", 18, 110, "top")
		gc:drawString("the   border.  How  long   can", 18, 130, "top")
		gc:drawString("you grow?", 18, 150, "top")
		gc:setFont("sansserif", "r", 8)
		gc:drawString("Press the escape ('esc') key at any time to return to the main menu.", 15, 190, "top")
	elseif scene == 2 then
		-- physics
		if #snake > 1 then
			for i = #snake, 2, -1 do
				snake[i].x = snake[i - 1].x
				snake[i].y = snake[i - 1].y
			end
		end
		if dir == 1 then
			snake[1].x = snake[1].x + scale
		elseif dir == 2 then
			snake[1].y = snake[1].y + scale
		elseif dir == 3 then
			snake[1].x = snake[1].x - scale
		elseif dir == 4 then
			snake[1].y = snake[1].y - scale
		end
		if snake[1].x < 0 or snake[1].x + scale > width or snake[1].y < 0 or snake[1].y + scale > height then
			scene = 3
		end
		if scene == 2 and #snake > 1 then
			for i = 2, #snake do
				if snake[1].x == snake[i].x and snake[1].y == snake[i].y then
					scene = 3
				end
			end
		end
		if scene == 2 and snake[1].x == apple.x and snake[1].y == apple.y then
			score = score + 1
			if score > highScore then
				highScore = score
			end
			RandomiseApplePosition()
			snake[#snake + 1] = Point(0, 0)
			snake[#snake].x = snake[#snake - 1].x
			snake[#snake].y = snake[#snake - 1].y
		end
		-- render
		gc:setColorRGB(255, 0, 0)
		apple:draw(gc)
		gc:setColorRGB(0, 80, 0)
		snake[1]:draw(gc)
		gc:setColorRGB(0, 180, 0)
		if #snake > 1 then
			for i = 2, #snake do
				snake[i]:draw(gc)
			end
		end
	elseif scene == 3 then
		-- render
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Snake", width / 2 - gc:getStringWidth("Snake") / 2, 14, "top")
		gc:setFont("sansserif", "r", 9)
		gc:drawString("Developed by Matthew James", width / 2 - gc:getStringWidth("Developed by Matthew James") / 2, 56, "top")
		gc:setFont("sansserif", "r", 10)
		gc:drawString("Game Over", width / 2 - gc:getStringWidth("Game Over") / 2, 100, "top")
		gc:drawString("Score: " .. score, width / 2 - gc:getStringWidth("Score: " .. score) / 2, 120, "top")
		gc:drawString("High Score: " .. highScore, width / 2 - gc:getStringWidth("High Score: " .. highScore) / 2, 140, "top")
	end
	timer.start(0.2)
end

function on.timer()
	platform.window:invalidate()
end

function on.arrowLeft()
	if scene == 2 then
		if dir ~= 1 then
			dir = 3
		end
	else
		platform.window:invalidate()
	end
end

function on.arrowRight()
	if scene == 2 then
		if dir ~= 3 then
			dir = 1
		end
	else
		platform.window:invalidate()
	end
end

function on.arrowUp()
	if scene == 0 then
		if active == 0 then
			active = 1
		else
			active = 0
		end
		platform.window:invalidate()
	elseif scene == 1 then
		platform.window:invalidate()
	elseif scene == 2 then
		if dir ~= 2 then
			dir = 4
		end
	end
end

function on.arrowDown()
	if scene == 0 then
		if active == 0 then
			active = 1
		else
			active = 0
		end
	elseif scene == 1 then
		platform.window:invalidate()
	elseif scene == 2 then
		if dir ~= 4 then
			dir = 2
		end
	end
	platform.window:invalidate()
end

function on.charIn(ch)
	if scene == 3 then
		scene = 2
		initGame()
		platform.window:invalidate()
	end
end

function on.escapeKey()
	scene = 0
	platform.window:invalidate()
end

function on.enterKey()
	if scene == 0 then
		if active == 0 then
			scene = 2
			initGame()
		else
			scene = 1
		end
	end
	platform.window:invalidate()
end