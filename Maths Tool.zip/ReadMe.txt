**************
* Maths Tool *
**************
- By Matthew James

How to use:
Menu:
In the menu use the arrow and enter keys to select a tool. Press enter at
any time to return to the menu.

Surd Simplifier:
Using the number keys on your calculator, input a number and press enter
and the Maths Tool will output the steps required to simplify the square
root of that number. (Note: the square root of a negative number is an
imaginary number. You cannot make the surd you input negative, but the
result if the surd was negative would be the same number with an i next
to it. For example: √-9 = 3 i)

How to get Maths Tool on your calculator:
If you have any software allowing you to send TNS files (any files ending
in '.tns') to your calculator, simply send the Maths Tool.tns file to your
calculator using that software. Otherwise, the easiest software that will
allow you to send TNS files to your calculator is the TI-Nspire Computer
Link Software which can be downloaded from:
https://education.ti.com/en/software/details/en/82035809F7E6474099944056CCB01C20/ti-nspire_computerlink

Maths Tool.tns is provided as is, without warranty. If you find any
bugs in this software, please report them by emailing me at
mattdestroyerpro@gmail.com. While I have tested this software extensively,
I cannot guarantee that this software will not damage your calculator or
result in any loss of data. I am not to be held responsible for any damage
that may occur to your calculator or any loss of data, nor am I to be held
responsible for any inconvenience previously mentioned damage may cause.