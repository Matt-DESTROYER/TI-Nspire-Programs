local scene = 0
local active = 0
local width, height = 0, 0
local surd_simplifier_input = ""
local surd_simplifier_output = {}

function on.resize()
	width = platform.window:width()
	height = platform.window:height()
end

function on.paint(gc)
	if scene == 0 then
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Maths Tool", width / 2 - gc:getStringWidth("Maths Tool") / 2, 14, "top")
		gc:setFont("sansserif", "r", 9)
		gc:drawString("Developed by Matthew James", width / 2 - gc:getStringWidth("Developed by Matthew James") / 2, 56, "top")
		gc:setFont("sansserif", "r", 14)
		if active == 0 then
			gc:drawString("> Surd Simplifier <", width / 2 - gc:getStringWidth("> Surd Simplifier <") / 2, 100)
		else
			gc:drawString("Surd Simplifier", width / 2 - gc:getStringWidth("Surd Simplifier") / 2, 100)
		end
		if active == 1 then
			gc:drawString("> Coming Soon <", width / 2 - gc:getStringWidth("> Coming Soon <") / 2, 130)
		else
			gc:drawString("Coming Soon", width / 2 - gc:getStringWidth("Coming Soon") / 2, 130)
		end
		if active == 2 then
			gc:drawString("> Coming Soon <", width / 2 - gc:getStringWidth("> Coming Soon <") / 2, 160)
		else
			gc:drawString("Coming Soon", width / 2 - gc:getStringWidth("Coming Soon") / 2, 160)
		end
		if active == 3 then
			gc:drawString("> Coming Soon <", width / 2 - gc:getStringWidth("> Coming Soon <") / 2, 190)
		else
			gc:drawString("Coming Soon", width / 2 - gc:getStringWidth("Coming Soon") / 2, 190)
		end
	elseif scene == 1 then
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Surd Simplifier", width / 2 - gc:getStringWidth("Surd Simplifier") / 2, 14, "top")
		gc:setFont("sansserif", "r", 9)
		gc:drawString("Enter a number (press enter to simplify your surd):", 20, 55, "top")
		gc:setFont("sansserif", "r", 10)
		gc:drawString("√" .. surd_simplifier_input, 20, 75, "top")
		for i = 1, #surd_simplifier_output do
			gc:drawString(surd_simplifier_output[i], 20, 75 + i * 11, "top")
		end
	elseif scene == 2 then
		
	elseif scene == 3 then
		
	end
end

function on.arrowUp()
	if scene == 0 then
		if active == 0 then
			active = 3
		else
			active = active - 1
		end
	end
	platform.window:invalidate()
end

function on.arrowDown()
	if scene == 0 then
		if active == 3 then
			active = 0
		else
			active = active + 1
		end
	end   
	platform.window:invalidate()
end

function on.charIn(ch)
	if scene == 1 then
		if ch == "0" or ch == "1" or ch == "2" or ch == "3" or ch == "4"  or ch == "5" or ch == "6" or ch == "7" or ch == "8" or ch == "9" then
			surd_simplifier_input = tostring(tonumber(surd_simplifier_input .. ch))
		end
	end
	platform.window:invalidate()
end

function on.escapeKey()
	scene = 0
	platform.window:invalidate()
end

function on.enterKey()
	if scene == 0 then
		scene = active + 1
	elseif scene == 1 then
		surd_simplifier_output = {}
		if surd_simplifier_input ~= "" then
			local surd = tonumber(surd_simplifier_input)
			surd_simplifier_input = ""
			local gpsf = nil
			for i = 2, surd - 1 do
				if surd / (i * i) == math.floor(surd / (i * i)) then
					gpsf = i * i
					break
				end
			end
			if gpsf == nil or gpsf == 1 then
				surd_simplifier_output[1] = "√" .. tostring(surd)
				surd_simplifier_output[2] = tostring(math.sqrt(surd))
			else
				surd_simplifier_output[1] = "√" .. tostring(surd)
				surd_simplifier_output[2] = "√" .. tostring(gpsf) .. " x " .. tostring(surd / gpsf)
				surd_simplifier_output[3] = tostring(math.sqrt(gpsf)) .. " x √" .. tostring(surd / gpsf)
				surd_simplifier_output[4] = tostring(math.sqrt(surd))
			end
		end
	end
	platform.window:invalidate()
end