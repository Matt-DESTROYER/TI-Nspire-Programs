local scene = 0
local active = 0
local scale = 10
local level = 1
local levels = {
	{
		"##########",
		"#@#      #",
		"# # ## # #",
		"# # #  # #",
		"# # ## ###",
		"# #  #   #",
		"#    #*###",
		"# ## ### #",
		"#  #     #",
		"##########"
	},
	{
		"##########",
		"#@#      #",
		"# # #### #",
		"#    # # #",
		"# # ##   #",
		"# #    # #",
		"# # ######",
		"# #   # *#",
		"#   #   ##",
		"##########"
	},
	{
		"####################",
		"#@#   #   # #      #",
		"# # ### # # ####   #",
		"#       #          #",
		"# ### # ####### #  #",
		"#  #  # #     # #  #",
		"#### ## ####  # # ##",
		"#    #  #* # ## #  #",
		"#  #    #       #  #",
		"####################"
	},
	{
		"####################",
		"#@# #              #",
		"# # ### ##### ######",
		"#           # #    #",
		"# ##### ##### #### #",
		"#       # #        #",
		"### ##### # ##### ##",
		"#       #   #      #",
		"# ### ######### ####",
		"#  #  #            #",
		"# ### # ### ###### #",
		"#     #   #   #    #",
		"# ####### ##########",
		"# #       #        #",
		"# ### ########### ##",
		"###   #            #",
		"# # # # ### ########",
		"# # # # #     #    #",
		"#   #   # #     # *#",
		"####################"
	},
	{
		"#############################",
		"#@          #     #   #     #",
		"# ##### # ### ###   ### #####",
		"# #   # # #   #   #         #",
		"# # # ### ### ### ###########",
		"#   # #     #               #",
		"# ### # ### ##### ### ### # #",
		"#   #     #     # # # # # # #",
		"### ####### ### # # # # ### #",
		"#     #   # #       #       #",
		"### ##### ### ####### # #####",
		"# #   #       #     # # #   #",
		"# # ### # ### ### # ### # ###",
		"#     # # #     # #   #     #",
		"# ####### # ##### ### ##### #",
		"#         # #       #       #",
		"##### ##### # ### ### ### ###",
		"#     #     # #   #     #  *#",
		"#############################"
	},
	{
		"###############################",
		"#@        #         #     #   #",
		"# ### ### # ####### # ### # # #",
		"# #   #   #     #       #   # #",
		"# ### ### ##### ############# #",
		"#   #   #       #       #     #",
		"# # ### ### ### ### ### # #####",
		"# #     #   #     #   #   #   #",
		"# ##### # # ### ### ####### ###",
		"# #     # #         #       # #",
		"# # ### # ######### # # ##### #",
		"#   #       #         #       #",
		"# # ###### ## # ### ##### #####",
		"# #         # # # #     #     #",
		"# ######### ### # ### # ##### #",
		"#       #             #     # #",
		"####### # # # ############# # #",
		"#   #   # # #   #   #   #   # #",
		"# #   #   # # #   #   #   # #*#",
		"###############################"
	},
	{
		"###############################",
		"#@#                           #",
		"# # ####### ##### ######### # #",
		"# # #     # #   # #       # # #",
		"# # ##### # # # ### ####### # #",
		"#   #     # #   # # #       # #",
		"### # # # # ##### # ### #######",
		"#   # # # #     #             #",
		"# ### # # # # ### ##### ##### #",
		"# #   # # # # #   # # #     # #",
		"# # ### # # # # ### # ### # # #",
		"# #   # # # ###     #     # # #",
		"# ##### ### # ### ##### # #####",
		"#           #     #     #     #",
		"# ##### ### ### ##### # ##### #",
		"# #   #       #             # #",
		"# # # ##### # ## ########## # #",
		"# # # #   ###  #      #   # ###",
		"#   #   #      #    #   # #  *#",
		"###############################"
	},
	{
		"###############################",
		"#@                            #",
		"# #     #  ###  ##### ####### #",
		"# ##   ## #   #    #  #       #",
		"# # # # # #####   #   ####### #",
		"# #  #  # #   #  #    #       #",
		"# #     # #   # ##### ####### #",
		"#                             #",
		"# # ####### ####### ### ### ###",
		"# # #   # # # # # # # # # # # #",
		"# # # # # # #   # # # ### # # #",
		"### # # # #   # # # # #   # # #",
		"# # # # # ##### # # # # # # # #",
		"#     #   #         #   #     #",
		"### ##### ########### #########",
		"#     #           #           #",
		"### ### ####### # ######### ###",
		"# # #         # #   #     ###*#",
		"#   # #  #  #   # #   #       #",
		"###############################"
	}
}
local highestLevel = 1
local px, py = -1, -1

function ResetPlayerPosition()
	x, y = 0, 0
	for i = 1, #levels[level] do
		y = y + 1
		x = 1
		for data in levels[level][i]:gmatch"." do
			if data == "@" then
				px = x
				py = y
			end
			x = x + 1
		end
	end
end

function on.resize()
	width = platform.window:width()
	height = platform.window:height()
end

function on.paint(gc)
	if scene == 0 then
		-- render
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Maze Escape", width / 2 - gc:getStringWidth("Maze Escape") / 2, 18, "top")
		gc:setFont("sansserif", "r", 9)
		gc:drawString("Developed by Matthew James", width / 2 - gc:getStringWidth("Developed by Matthew James") / 2, 56, "top")
		gc:setFont("sansserif", "r", 14)
		if active == 0 then
			gc:drawString("> Play <", width / 2 - gc:getStringWidth("> Play <") / 2, 100)
		else
			gc:drawString("Play", width / 2 - gc:getStringWidth("Play") / 2, 100)
		end
		if active == 1 then
			gc:drawString("> Continue <", width / 2 - gc:getStringWidth("> Continue <") / 2, 130)
		else
			gc:drawString("Continue", width / 2 - gc:getStringWidth("Continue") / 2, 130)
		end
		if active == 2 then
			gc:drawString("> How <", width / 2 - gc:getStringWidth("> How <") / 2, 160)
		else
			gc:drawString("How", width / 2 - gc:getStringWidth("How") / 2, 160)
		end
	elseif scene == 1 then
		-- render
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Maze Escape", width / 2 - gc:getStringWidth("Maze Escape") / 2, 18, "top")
		gc:setFont("sansserif", "r", 14)
		gc:drawString("Using the arrow keys on your", 18, 60, "top")
		gc:drawString("calculator   navigate  through", 18, 80, "top")
		gc:drawString("mazes   of   black  walls  and", 18, 100, "top")
		gc:drawString("reach   the   green  exit.  Can", 18, 120, "top")
		gc:drawString("you escape all of the mazes?", 18, 140, "top")
		gc:setFont("sansserif", "r", 8)
		gc:drawString("Press the escape ('esc') key at any time to return to the main menu.", 15, 190, "top")
	elseif scene == 2 then
		-- physics
		if levels[level][py]:sub(px, px) == "*" then
			level = level + 1
			if level > highestLevel then
				highestLevel = level
			end
			if level > #levels then
				scene = 3
			else
				ResetPlayerPosition()
			end
		end
		-- render
		if level <= #levels then
			local _x, _y = 0, 0
			for i = 1, #levels[level] do
				for data in levels[level][i]:gmatch"." do
					if _x == (px - 1) * scale and _y == (py - 1) * scale then
						gc:setColorRGB(0, 0, 180)
						gc:fillRect(_x, _y, scale, scale)
					elseif data == "#" then
						gc:setColorRGB(0, 0, 0)
						gc:fillRect(_x, _y, scale, scale)
					elseif data == "*" then
						gc:setColorRGB(0, 120, 0)
						gc:fillRect(_x, _y, scale, scale)
					end
					_x = _x + scale
				end
				_x = 0
				_y = _y + scale
			end
		end
	elseif scene == 3 then
		-- render
		gc:setColorRGB(0, 0, 0)
		gc:setFont("sansserif", "r", 20)
		gc:drawString("Maze Escape", width / 2 - gc:getStringWidth("Maze Escape") / 2, 18, "top")
		gc:setFont("sansserif", "r", 12)
		gc:drawString("Developed by Matthew James", width / 2 - gc:getStringWidth("Developed by Matthew James") / 2, 60, "top")
		gc:setFont("sansserif", "r", 10)
		gc:drawString("Congratulations, you escaped all the mazes!", width / 2 - gc:getStringWidth("Congratulations, you escaped all the mazes!") / 2, 100, "top")
	end
	timer.start(0.015)
end

function on.timer()
	platform.window:invalidate()
end

function on.arrowLeft()
	if scene == 2 then
		if levels[level][py]:sub(px - 1, px - 1) ~= "#" then
			px = px - 1
		end
	end
	platform.window:invalidate()
end

function on.arrowRight()
	if scene == 2 then
		if levels[level][py]:sub(px + 1, px + 1) ~= "#" then
			px = px + 1
		end
	end
	platform.window:invalidate()
end

function on.arrowUp()
	if scene == 0 then
		if active == 0 then
			active = 2
		else
			active = active - 1
		end
	elseif scene == 2 then
		if levels[level][py - 1]:sub(px, px) ~= "#" then
			py = py - 1
		end
	end
	platform.window:invalidate()
end

function on.arrowDown()
	if scene == 0 then
		if active == 2 then
			active = 0
		else
			active = active + 1
		end
	elseif scene == 2 then
		if levels[level][py + 1]:sub(px, px) ~= "#" then
			py = py + 1
		end
	end
	platform.window:invalidate()
end

function on.escapeKey()
	scene = 0
	platform.window:invalidate()
end

function on.enterKey()
	if scene == 0 then
		if active == 0 then
			scene = 2
			level = 1
			ResetPlayerPosition()
		elseif active == 1 then
			if level > #levels then
				scene = 3
			else
				scene = 2
				level = highestLevel
				ResetPlayerPosition()
			end
		else
			scene = 1
		end
	end
	platform.window:invalidate()
end