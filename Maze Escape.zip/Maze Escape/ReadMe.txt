***************
* Maze Escape *
***************
- By Matthew James

How to play:
In the menu use the arrow keys and enter to select an option. In-game
use the arrow keys on your calculator, navigate through the mazes
and reach the green exit in each level.

How to get Maze Escape on your calculator:
If you have any software allowing you to send TNS files (any files
ending in '.tns') to your calculator, simply send the Maze Escape.tns
file to your calculator using that software. Otherwise, the easiest
software that will allow you to send TNS files to your calculator is
the TI-Nspire Computer Link Software which can be downloaded from:
https://education.ti.com/en/software/details/en/82035809F7E6474099944056CCB01C20/ti-nspire_computerlink

Maze Escape.tns is provided as is, without warranty. If you find any
bugs in this game, please report them by emailing me at
mattdestroyerpro@gmail.com. While I have tested this game extensively,
I cannot guarantee that this game will not damage your calculator or
result in any loss of data. I am not to be held responsible for any
damage that may occur to your calculator or any loss of data, nor am I
to be held responsible for any inconvenience previously mentioned
damage may cause.